const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');


const userRoutes = require('./routes/user');

const ticketRoutes = require('./routes/ticket');

mongoose.connect('mongodb+srv://clem:Ouiouioui54@cluster0.myapl5w.mongodb.net/',
  { useNewUrlParser: true,
    useUnifiedTopology: true })
  .then(() => console.log('Connexion à MongoDB réussie !'))
  .catch(() => console.log('Connexion à MongoDB échouée !'));

const app = express();

app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content, Accept, Content-Type, Authorization');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
    next();
});

app.use(bodyParser.json());

app.use('/api/ticket', ticketRoutes);

app.use('/api/ticket', ticketRoutes);
app.use('/api/auth', userRoutes);
 /* 
 app.post('/api/ticket', (req, res, next) => {
    delete req.body._id;
    const ticket = new Ticket({
      ...req.body
    });
    ticket.save()
      .then(() => res.status(201).json({ message: 'Objet enregistré !'}))
      .catch(error => res.status(400).json({ error }));
});

app.get('/api/ticket/:id', (req, res, next) => {
    Ticket.findOne({ _id: req.params.id })
      .then(ticket => res.status(200).json(ticket))
      .catch(error => res.status(404).json({ error }));
});

app.put('/api/ticket/:id', (req, res, next) => {
    Ticket.updateOne({ _id: req.params.id }, { ...req.body, _id: req.params.id })
      .then(() => res.status(200).json({ message: 'Objet modifié !'}))
      .catch(error => res.status(400).json({ error }));
});

app.delete('/api/ticket/:id', (req, res, next) => {
    Ticket.deleteOne({ _id: req.params.id })
      .then(() => res.status(200).json({ message: 'Objet supprimé !'}))
      .catch(error => res.status(400).json({ error }));
});
   

app.get('/api/ticket', (req, res, next) => {
    Ticket.find()
    .then(tickets => res.status(200).json(tickets))
    .catch(error => res.status(400).json({ error }));
});
*/

module.exports = app;